// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Shared utility functions for mod_airoleplay AMD modules.
 *
 * @module     mod_airoleplay/utils
 * @copyright  2025 Pluginia
 * @license    https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

/**
 * Makes an AJAX request to a Moodle endpoint.
 *
 * @param {string} url      - The endpoint URL.
 * @param {Object} data     - POST data (will be JSON-stringified).
 * @param {string} sesskey  - Moodle session key for CSRF protection.
 * @returns {Promise<Object>} Resolved with parsed JSON response.
 */
export const ajaxPost = (url, data, sesskey) => {
    return fetch(url, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-Requested-With': 'XMLHttpRequest',
        },
        body: JSON.stringify({...data, sesskey}),
    }).then(res => {
        if (!res.ok) {
            throw new Error(`HTTP ${res.status}`);
        }
        return res.json();
    });
};

/**
 * Formats seconds into MM:SS display string.
 *
 * @param {number} totalSeconds - Total seconds remaining.
 * @returns {string} Formatted time string.
 */
export const formatTime = (totalSeconds) => {
    const minutes = Math.floor(Math.abs(totalSeconds) / 60);
    const seconds = Math.abs(totalSeconds) % 60;
    return `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
};

/**
 * Plays a beep sound using the Web Audio API.
 *
 * @param {number} frequency  - Tone frequency in Hz (default 440).
 * @param {number} duration   - Duration in milliseconds (default 200).
 * @param {number} volume     - Volume 0-1 (default 0.3).
 */
export const playBeep = (frequency = 440, duration = 200, volume = 0.3) => {
    try {
        const ctx = new (window.AudioContext || window.webkitAudioContext)();
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();

        osc.connect(gain);
        gain.connect(ctx.destination);

        osc.frequency.value = frequency;
        gain.gain.setValueAtTime(volume, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + duration / 1000);

        osc.start(ctx.currentTime);
        osc.stop(ctx.currentTime + duration / 1000);
    } catch (e) {
        // AudioContext not available — silently ignore.
    }
};

/**
 * Shows a status message in a container element.
 *
 * @param {HTMLElement} el      - The container element.
 * @param {string}      message - The message text.
 * @param {string}      type    - Bootstrap alert type ('info', 'success', 'warning', 'danger').
 */
export const showStatus = (el, message, type = 'info') => {
    if (!el) {
        return;
    }
    el.className = `airoleplay-status-message alert alert-${type}`;
    el.textContent = message;
    el.style.display = 'block';
};
