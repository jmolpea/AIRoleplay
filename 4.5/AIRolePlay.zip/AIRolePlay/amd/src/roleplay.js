// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * AI Roleplay UI: TTS playback, STT capture, avatar animations, avatar addressing detection.
 *
 * @module     mod_airoleplay/roleplay
 * @copyright  2025 Pluginia
 * @license    https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

import {ajaxPost, showStatus, formatTime, playBeep} from './utils';
import {get_string as getString} from 'core/str';

let cfg = {};
let sessionActive     = false;
let currentTurn       = 0;
let sessionTimer      = null;
let remainingSeconds  = 0;
let recognition       = null;
let isRecognising     = false;
let currentTranscript = '';
let audioCtx          = null;
let pttSetupDone      = false;
let pendingSubmit     = false;

// Rotation state: tracks next avatar index for rotation (0-based).
let rotationIndex = 0;

/**
 * Initialises the roleplay module.
 *
 * @param {Object} config
 * @param {number} config.cmid            Course module id.
 * @param {string} config.sesskey         Moodle session key.
 * @param {number} config.submissionid    Submission id.
 * @param {number} config.durationmins    Session duration in minutes.
 * @param {number} config.numavatars      Number of active avatars (1-3).
 * @param {Array}  config.avatarnames     [{index: 1, name: 'Alex'}, ...] for addressing detection.
 * @param {string} config.speechlang      BCP-47 language code for Web Speech API.
 * @param {string} config.submissionstatus Current submission status.
 */
export const init = (config) => {
    cfg = config;

    const roleplayPanel = document.getElementById('airoleplay_roleplay_panel');
    if (!roleplayPanel) {
        return;
    }

    // Show ready screen when panel is visible and session not yet started.
    const observer = new MutationObserver(() => {
        if (!roleplayPanel.classList.contains('d-none') && !sessionActive) {
            observer.disconnect();
            showReadyScreen(roleplayPanel);
        }
    });
    observer.observe(roleplayPanel, {attributes: true, attributeFilter: ['class']});

    if (!roleplayPanel.classList.contains('d-none') && !sessionActive) {
        showReadyScreen(roleplayPanel);
    }

    // If evaluation is already pending (page reload after session ends), start polling.
    if (['submitted', 'grading'].includes(cfg.submissionstatus)) {
        const evalStatusEl = document.getElementById('airoleplay_eval_status');
        pollEvaluationStatus(evalStatusEl);
    }
};

// ------------------------------------------------------------------
// Ready screen
// ------------------------------------------------------------------

/**
 * Shows the ready screen before session starts.
 *
 * @param {HTMLElement} roleplayPanel
 */
const showReadyScreen = async (roleplayPanel) => {
    const room = roleplayPanel.querySelector('.airoleplay-room');
    if (room) {
        room.style.display = 'none';
    }

    const [title, notice, btnLabel] = await Promise.all([
        getString('roleplay_ready_title', 'mod_airoleplay'),
        getString('roleplay_ready_notice', 'mod_airoleplay'),
        getString('roleplay_start_btn', 'mod_airoleplay'),
    ]);

    const screen = document.createElement('div');
    screen.id = 'airoleplay_ready_screen';
    screen.className = 'text-center p-4 my-4';
    screen.innerHTML = `
        <h3 class="mb-3">${title}</h3>
        <div class="alert alert-warning d-inline-block text-start mb-4" style="max-width:600px">
            <strong>⚠️</strong> ${notice}
        </div>
        <br>
        <button type="button" class="btn btn-primary btn-lg" id="airoleplay_start_btn">
            🎭 ${btnLabel}
        </button>
    `;

    roleplayPanel.insertBefore(screen, room ?? roleplayPanel.firstChild);

    document.getElementById('airoleplay_start_btn').addEventListener('click', () => {
        screen.remove();
        if (room) {
            room.style.display = '';
        }
        if (!audioCtx) {
            audioCtx = new (window.AudioContext || window.webkitAudioContext)();
        }
        startSession();
    });
};

// ------------------------------------------------------------------
// Session lifecycle
// ------------------------------------------------------------------

/**
 * Starts the roleplay session.
 */
const startSession = async () => {
    sessionActive    = true;
    currentTurn      = 0;
    rotationIndex    = 0;
    remainingSeconds = cfg.durationmins * 60;

    startSessionTimer();
    setupSpeechRecognition();

    const statusEl  = document.getElementById('airoleplay_status');
    const loadingMsg = await getString('roleplay_loading', 'mod_airoleplay');
    showStatus(statusEl, loadingMsg, 'info');

    try {
        const data = await ajaxPost(
            M.cfg.wwwroot + '/mod/airoleplay/ajax.php',
            {action: 'roleplay_opening', submissionid: cfg.submissionid, cmid: cfg.cmid},
            cfg.sesskey
        );

        if (data.success) {
            await deliverAvatarTurn(data.avatar, data.text, data.audio_base64);
            showPushToTalk();
        } else {
            showStatus(statusEl, data.error || 'Failed to start roleplay', 'danger');
        }
    } catch (e) {
        showStatus(document.getElementById('airoleplay_status'), e.message, 'danger');
    }
};

/**
 * Starts the countdown timer.
 */
const startSessionTimer = () => {
    const timerEl = document.getElementById('airoleplay_timer');
    updateTimerDisplay(timerEl);

    sessionTimer = setInterval(async () => {
        remainingSeconds--;
        updateTimerDisplay(timerEl);

        if (remainingSeconds <= 0) {
            clearInterval(sessionTimer);
            endSession();
        } else if (remainingSeconds === 60) {
            playBeep(660, 400, 0.3);
            const msg = await getString('warning_1min', 'mod_airoleplay');
            showStatus(document.getElementById('airoleplay_status'), msg, 'warning');
        }
    }, 1000);
};

/**
 * Updates the timer display element.
 *
 * @param {HTMLElement} timerEl
 */
const updateTimerDisplay = (timerEl) => {
    if (timerEl) {
        timerEl.textContent = formatTime(remainingSeconds);
        timerEl.className   = 'airoleplay-timer' + (remainingSeconds <= 60 ? ' urgent' : '');
    }
};

/**
 * Gracefully ends the session.
 */
const endSession = async () => {
    sessionActive = false;
    hidePushToTalk();

    const statusEl  = document.getElementById('airoleplay_status');
    const closingMsg = await getString('roleplay_ending', 'mod_airoleplay');
    showStatus(statusEl, closingMsg, 'info');

    try {
        const data = await ajaxPost(
            M.cfg.wwwroot + '/mod/airoleplay/ajax.php',
            {action: 'roleplay_closing', submissionid: cfg.submissionid, cmid: cfg.cmid, turn: currentTurn},
            cfg.sesskey
        );

        if (data.success) {
            await deliverAvatarTurn(data.avatar, data.text, data.audio_base64);
            if (data.evaluation_status === 'graded') {
                const doneMsg = await getString('evaluation_complete', 'mod_airoleplay');
                showStatus(statusEl, doneMsg, 'success');
                setTimeout(() => window.location.reload(), 2000);
                return;
            }
        }
    } catch (e) {
        // Ignore closing errors.
    }

    const finishedMsg = await getString('roleplay_finished', 'mod_airoleplay');
    showStatus(document.getElementById('airoleplay_status'), finishedMsg, 'info');
    pollEvaluationStatus(document.getElementById('airoleplay_status'));
};

// ------------------------------------------------------------------
// Avatar turn delivery (TTS + animation)
// ------------------------------------------------------------------

/**
 * Switches an avatar's video between idle and talking states.
 *
 * @param {number}  avatarNum - Avatar number (1-3).
 * @param {boolean} talking   - True to play talking loop, false for idle.
 */
const setAvatarTalking = (avatarNum, talking) => {
    const video = document.getElementById(`avatar_video_${avatarNum}`);
    if (!video) {
        return;
    }
    const newSrc = talking ? video.dataset.talking : video.dataset.idle;
    if (video.getAttribute('src') !== newSrc) {
        video.src  = newSrc;
        video.loop = true;
        video.play().catch(() => {});
    }
};

/**
 * Delivers an avatar's message: shows text, plays audio, animates avatar.
 *
 * @param {number} avatar      Avatar number (1-3).
 * @param {string} text        Spoken text.
 * @param {string} audioBase64 Base64-encoded MP3 (may be empty).
 */
const deliverAvatarTurn = async (avatar, text, audioBase64) => {
    currentTurn++;
    appendToTranscript(`avatar_${avatar}`, text, avatar);
    setActiveAvatar(avatar);

    if (audioBase64) {
        await playAudioBase64(audioBase64, avatar);
    } else {
        setAvatarTalking(avatar, true);
        await new Promise(r => setTimeout(r, Math.min(5000, text.length * 60)));
        setAvatarTalking(avatar, false);
    }

    clearActiveAvatar();
};

/**
 * Plays base64-encoded MP3 audio using Web Audio API with lip sync.
 *
 * @param {string} base64  Base64 MP3 data.
 * @param {number} avatar  Avatar number for lip-sync.
 * @returns {Promise<void>}
 */
const playAudioBase64 = (base64, avatar) => {
    return new Promise((resolve) => {
        try {
            const binary = atob(base64);
            const bytes  = new Uint8Array(binary.length);
            for (let i = 0; i < binary.length; i++) {
                bytes[i] = binary.charCodeAt(i);
            }

            const avatarEl = document.getElementById(`airoleplay_avatar_${avatar}`);
            setAvatarTalking(avatar, true);
            avatarEl?.classList.add('speaking');

            if (!audioCtx) {
                const blob  = new Blob([bytes], {type: 'audio/mpeg'});
                const url   = URL.createObjectURL(blob);
                const audio = new Audio(url);
                audio.onended = audio.onerror = () => {
                    avatarEl?.classList.remove('speaking');
                    setAvatarTalking(avatar, false);
                    URL.revokeObjectURL(url);
                    resolve();
                };
                audio.play().catch(() => resolve());
                return;
            }

            audioCtx.decodeAudioData(bytes.buffer.slice(0), (audioBuffer) => {
                const source   = audioCtx.createBufferSource();
                const analyser = audioCtx.createAnalyser();
                analyser.fftSize = 256;
                source.buffer = audioBuffer;
                source.connect(analyser);
                analyser.connect(audioCtx.destination);

                const dataArray = new Uint8Array(analyser.frequencyBinCount);
                let animFrame   = null;

                const animateMouth = () => {
                    analyser.getByteTimeDomainData(dataArray);
                    let sum = 0;
                    for (let i = 0; i < dataArray.length; i++) {
                        const v = (dataArray[i] - 128) / 128;
                        sum += v * v;
                    }
                    const rms = Math.sqrt(sum / dataArray.length);
                    const ry  = Math.min(6, rms * 50);
                    const mouthEl = document.getElementById(`mouth_open_${avatar}`);
                    if (mouthEl) {
                        mouthEl.setAttribute('ry', ry.toFixed(1));
                    }
                    animFrame = requestAnimationFrame(animateMouth);
                };
                animFrame = requestAnimationFrame(animateMouth);

                source.onended = () => {
                    cancelAnimationFrame(animFrame);
                    const mouthEl2 = document.getElementById(`mouth_open_${avatar}`);
                    if (mouthEl2) {
                        mouthEl2.setAttribute('ry', '0');
                    }
                    avatarEl?.classList.remove('speaking');
                    setAvatarTalking(avatar, false);
                    resolve();
                };

                source.start(0);
            }, () => {
                avatarEl?.classList.remove('speaking');
                setAvatarTalking(avatar, false);
                resolve();
            });
        } catch (e) {
            resolve();
        }
    });
};

/**
 * Highlights the currently speaking avatar.
 *
 * @param {number} avatar Avatar number.
 */
const setActiveAvatar = (avatar) => {
    const numavatars = cfg.numavatars || 1;
    for (let i = 1; i <= numavatars; i++) {
        const el = document.getElementById(`airoleplay_avatar_${i}`);
        if (el) {
            el.classList.toggle('active-speaker', i === avatar);
            el.classList.toggle('inactive-speaker', i !== avatar);
        }
    }
};

/** Clears all speaker highlights. */
const clearActiveAvatar = () => {
    const numavatars = cfg.numavatars || 1;
    for (let i = 1; i <= numavatars; i++) {
        const el = document.getElementById(`airoleplay_avatar_${i}`);
        if (el) {
            el.classList.remove('active-speaker', 'inactive-speaker');
        }
    }
};

// ------------------------------------------------------------------
// Speech recognition (STT)
// ------------------------------------------------------------------

/**
 * Initialises the Web Speech API recognition object.
 */
const setupSpeechRecognition = () => {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) {
        return;
    }

    recognition = new SR();
    recognition.continuous     = true;
    recognition.interimResults = true;
    recognition.lang           = cfg.speechlang || document.documentElement.lang || 'en-US';

    recognition.onresult = (e) => {
        let interim = '';
        let final   = '';
        for (let i = e.resultIndex; i < e.results.length; i++) {
            const t = e.results[i][0].transcript;
            if (e.results[i].isFinal) {
                final += t;
            } else {
                interim += t;
            }
        }
        currentTranscript += final;

        const transcriptEl = document.getElementById('airoleplay_transcript');
        if (transcriptEl) {
            const liveEl = transcriptEl.querySelector('.live-transcript') ||
                (() => {
                    const el = document.createElement('div');
                    el.className = 'live-transcript participant-turn';
                    transcriptEl.appendChild(el);
                    return el;
                })();
            liveEl.textContent = currentTranscript + (interim ? ' ' + interim : '');
        }
    };

    recognition.onerror = (e) => {
        if (e.error !== 'no-speech') {
            // Non-critical error.
        }
    };

    recognition.onend = () => {
        if (pendingSubmit) {
            pendingSubmit = false;
            let transcript = currentTranscript;
            if (!transcript.trim()) {
                const liveEl = document.querySelector('#airoleplay_transcript .live-transcript');
                transcript = liveEl ? liveEl.textContent.trim() : '';
            }
            submitParticipantResponse(transcript);
        }
    };
};

/** Shows the push-to-talk button. */
const showPushToTalk = () => {
    document.getElementById('airoleplay_ptt_btn')?.classList.remove('d-none');
    if (!pttSetupDone) {
        pttSetupDone = true;
        setupPTT();
    }
};

/** Hides the push-to-talk button. */
const hidePushToTalk = () => {
    document.getElementById('airoleplay_ptt_btn')?.classList.add('d-none');
    if (recognition && isRecognising) {
        recognition.stop();
    }
};

/**
 * Sets up push-to-talk events on the PTT button.
 */
const setupPTT = () => {
    const pttBtn = document.getElementById('airoleplay_ptt_btn');
    if (!pttBtn) {
        return;
    }

    const startListening = () => {
        if (!sessionActive) {
            return;
        }
        currentTranscript = '';
        isRecognising     = true;
        pttBtn.classList.add('active');

        if (recognition) {
            try {
                recognition.start();
            } catch (e) {
                // Already started.
            }
        }
    };

    const stopListening = () => {
        if (!isRecognising) {
            return;
        }
        isRecognising = false;
        pttBtn.classList.remove('active');

        if (recognition) {
            pendingSubmit = true;
            recognition.stop();
            setTimeout(() => {
                if (pendingSubmit) {
                    pendingSubmit = false;
                    let transcript = currentTranscript;
                    if (!transcript.trim()) {
                        const liveEl = document.querySelector('#airoleplay_transcript .live-transcript');
                        transcript = liveEl ? liveEl.textContent.trim() : '';
                    }
                    submitParticipantResponse(transcript);
                }
            }, 1000);
        } else {
            submitParticipantResponse(currentTranscript);
        }
    };

    pttBtn.addEventListener('mousedown', startListening);
    pttBtn.addEventListener('mouseup', stopListening);
    pttBtn.addEventListener('touchstart', e => { e.preventDefault(); startListening(); }, {passive: false});
    pttBtn.addEventListener('touchend', e => { e.preventDefault(); stopListening(); }, {passive: false});
};

// ------------------------------------------------------------------
// Participant response submission
// ------------------------------------------------------------------

/**
 * Sends the participant's transcribed response to the server.
 *
 * Detects if the participant addressed a specific avatar by name and sends
 * that as preferred_avatar so the server can override rotation.
 *
 * @param {string} transcript The transcribed response text.
 */
const submitParticipantResponse = async (transcript) => {
    if (!sessionActive || !transcript.trim()) {
        return;
    }

    hidePushToTalk();
    appendToTranscript('participant', transcript, 0);

    const statusEl   = document.getElementById('airoleplay_status');
    const thinkingMsg = await getString('roleplay_thinking', 'mod_airoleplay');
    showStatus(statusEl, thinkingMsg, 'info');

    // Compute next avatar by rotation (cycles through 1..numavatars).
    const numavatars    = cfg.numavatars || 1;
    const suggestedAvatar = (rotationIndex % numavatars) + 1;
    rotationIndex++;

    // Detect if participant directly addressed a specific avatar by name.
    const preferredAvatar = detectAddressedAvatar(transcript);

    try {
        const data = await ajaxPost(
            M.cfg.wwwroot + '/mod/airoleplay/ajax.php',
            {
                action:           'roleplay_turn',
                submissionid:     cfg.submissionid,
                cmid:             cfg.cmid,
                response:         transcript,
                suggested_avatar: suggestedAvatar,
                preferred_avatar: preferredAvatar,
                turn:             currentTurn + 1,
            },
            cfg.sesskey
        );

        if (data.success) {
            await deliverAvatarTurn(data.avatar, data.text, data.audio_base64);
            if (sessionActive) {
                showPushToTalk();
            }
        } else {
            showStatus(statusEl, data.error || 'Error processing response', 'danger');
            if (sessionActive) {
                showPushToTalk();
            }
        }
    } catch (e) {
        showStatus(statusEl, 'Error: ' + e.message, 'danger');
        if (sessionActive) {
            showPushToTalk();
        }
    }
};

/**
 * Detects if the participant's transcript addresses a specific avatar by name.
 *
 * Checks for avatar names at the start of the utterance (direct address pattern)
 * or anywhere in the text (reference pattern). Returns the avatar index if found,
 * or 0 if no specific avatar is identified.
 *
 * @param {string} transcript The participant's spoken transcript.
 * @returns {number} Avatar index (1-3) or 0 for no specific avatar.
 */
const detectAddressedAvatar = (transcript) => {
    if (!cfg.avatarnames || cfg.avatarnames.length <= 1) {
        return 0; // With only 1 avatar, no need to detect.
    }

    const lower = transcript.toLowerCase().trim();

    // Priority 1: Name appears at the very beginning (most reliable indicator of direct address).
    for (const avatar of cfg.avatarnames) {
        const name = avatar.name.toLowerCase();
        if (lower.startsWith(name) || lower.startsWith(name + ',') || lower.startsWith(name + ':')) {
            return avatar.index;
        }
    }

    // Priority 2: Name appears anywhere in the transcript (less certain but still a signal).
    for (const avatar of cfg.avatarnames) {
        const name = avatar.name.toLowerCase();
        if (lower.includes(name)) {
            return avatar.index;
        }
    }

    return 0; // No specific avatar detected — use suggested rotation.
};

// ------------------------------------------------------------------
// Conversation log & transcript UI
// ------------------------------------------------------------------

/**
 * Appends a turn to the conversation log and transcript area.
 *
 * @param {string} speaker Speaker identifier ('avatar_1', 'avatar_2', 'avatar_3', 'participant').
 * @param {string} text    Message text.
 * @param {number} avatar  Avatar number (for colour coding; 0 for participant).
 */
const appendToTranscript = (speaker, text, avatar) => {
    const transcriptEl = document.getElementById('airoleplay_transcript');
    const logEl        = document.getElementById('airoleplay_conversation_log');

    const isParticipant = speaker === 'participant';
    const itemClass     = isParticipant ? 'participant-turn' : `avatar-turn avatar-${avatar}`;
    const avatarName    = cfg.avatarnames?.find(a => a.index === avatar)?.name || `Avatar ${avatar}`;
    const label         = isParticipant ? '🎭 ' + (cfg.participantlabel || 'You') : '💬 ' + avatarName;

    [transcriptEl, logEl].forEach(container => {
        if (!container) {
            return;
        }
        container.querySelector('.live-transcript')?.remove();

        const item = document.createElement('div');
        item.className = 'transcript-item ' + itemClass;
        item.innerHTML = `<span class="speaker-label">${label}</span><span class="message-text">${escapeHtml(text)}</span>`;
        container.appendChild(item);
        container.scrollTop = container.scrollHeight;
    });
};

// ------------------------------------------------------------------
// Evaluation polling
// ------------------------------------------------------------------

/**
 * Polls the server until the final evaluation is ready, then reloads.
 *
 * @param {HTMLElement} statusEl Status element.
 */
const pollEvaluationStatus = (statusEl) => {
    const pollUrl = M.cfg.wwwroot + '/mod/airoleplay/ajax.php';
    let attempts  = 0;

    const poll = async () => {
        attempts++;
        if (attempts > 60) {
            return;
        }

        try {
            const url  = `${pollUrl}?action=check_evaluation&submissionid=${cfg.submissionid}` +
                `&sesskey=${cfg.sesskey}&cmid=${cfg.cmid}`;
            const res  = await fetch(url);
            const data = await res.json();

            if (data.status === 'graded') {
                const doneMsg = await getString('evaluation_complete', 'mod_airoleplay');
                showStatus(statusEl, doneMsg, 'success');
                setTimeout(() => window.location.reload(), 2000);
            } else if (data.status === 'error') {
                showStatus(statusEl, data.error || 'Evaluation failed', 'danger');
            } else {
                setTimeout(poll, 5000);
            }
        } catch (e) {
            setTimeout(poll, 5000);
        }
    };

    setTimeout(poll, 5000);
};

// ------------------------------------------------------------------
// Helpers
// ------------------------------------------------------------------

/**
 * Escapes HTML special characters to prevent XSS.
 *
 * @param {string} str Raw string.
 * @returns {string} Escaped string.
 */
const escapeHtml = (str) => String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
